import numpy as np

g1 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_1.npy')
g2 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_2.npy')
g3 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_3.npy')
g4 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_4.npy')
g5 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_5.npy')
g6 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_6.npy')
g7 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_7.npy')
g8 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_8.npy')
g9 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_9.npy')
g10 = np.load('/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCN_ENCODED_MATRIX_10.npy')

gf = np.vstack([g1, g2, g3, g4, g5, g6, g7, g8, g9, g10])












