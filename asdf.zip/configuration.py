"""
Written on October 29, 2020

This provides parameters.

"""


clinical_filepath = '/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GCNencoding/data/Subtype_Info.csv'
gene_data = '/data2/project/jihyun_kim/data/CSN_BRCA/CSN/GEM_fs_0001.csv'
mode = 'standard'
gcn_mode = True














