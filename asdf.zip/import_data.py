"""
Written on October 29, 2020
This provide train, test data for learning.

- Data format
    -> clinical data:
        data: person_id, clinical information
        label: cancer type, subtype, etc (labels should be located at the last column)
    -> gene data: person_id, gene information
        data: person_id, gene information
        label: same as clinical data


Revised on November 9, 2020
    - Added survival data join function

"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler


def CLINICAL_DATA_LOAD(clinical_filepath):
    tmp = np.loadtxt(clinical_filepath, dtype=str, delimiter=',')
    STATUS = pd.DataFrame({'SAMPLE': np.transpose(tmp)[0], 'class': np.transpose(tmp)[-1]})
    # NUM_CLASSES = len(set(np.transpose(tmp)[-1]))  # For output layer

    return STATUS


def NORMALIZATION(data, mode):
    if mode == 'standard':
        scaler = StandardScaler()
    if mode == 'minmax':
        scaler = MinMaxScaler()

    normalized = scaler.fit_transform(data)

    return normalized


def DATA_JOIN(status, gene_data, mode):
    """
    - This function join clinical data and gene_data on person id
    - Normalization mode is required
    """
    print('Gene data [{}] loading...'.format(gene_data))
    data = np.transpose(np.loadtxt(gene_data, dtype=str, delimiter=','))
    print('Size: %s' % str(data.shape))
    print('Done')
    data[0, 0] = 'SAMPLE'  # For joining between clinical data and gene data

    print('Data Merging...')
    data = pd.DataFrame(data=data[1:], columns=data[0])
    data = pd.merge(data, status, how='inner', on='SAMPLE')
    data = np.delete(np.array(data), 0, 1)
    data = np.array(data, dtype=float)
    print('Done')

    # print('Data discription...')
    # datadisc = [['Da']]

    data = np.transpose(data)
    puredata = np.transpose(data[:-1])
    labels = data[-1]

    normalized = np.transpose(NORMALIZATION(puredata, mode))

    concatenate = np.concatenate((normalized, [labels]))
    data = np.transpose(concatenate)
    num_classes = len(set(concatenate[-1]))

    clscnt = [0] * num_classes
    for i in labels:
        clscnt[int(i)] += 1

    print('========================= Data Discription ==========================')
    print('')
    print('         Joined Size: %10s' % str(data.shape))
    print('         # of classes: %8d' % num_classes)
    print('         # of variables: %9d' % (len(data[0])-1))
    for i in range(num_classes):
        print('         # of %d class: %10d' % (i, clscnt[i]))
    print('')
    print('=====================================================================')

    return data, num_classes


def COMBINE(data1, data2):
    labels = np.array(np.transpose(data1)[-1])
    labels = np.transpose(np.expand_dims(labels, axis=0))

    gem = np.delete(data1, -1, 1)
    ndm = np.delete(data2, -1, 1)
    union = np.concatenate((gem, ndm, labels), axis=1)

    return union


def KFOLD(DATA, KFOLD):
    NUM_CLASSES = len(set(np.transpose(DATA)[-1]))

    CLS_TMP = list()
    for i in range(NUM_CLASSES):
        clssp = []
        for j in DATA:
            if int(j[-1]) == i:
                clssp.append(j)
        clssp = np.array(clssp)
        CLS_TMP.append(clssp)

    def KFOLD_SEPARATION(sample):
        getsam = sample
        kfoldset = []
        for i in range(KFOLD):
            putnum = len(getsam) // (KFOLD - i)
            wtput = getsam[:putnum]
            kfoldset.append(wtput)
            getsam = getsam[putnum:]

        return kfoldset

    SEPARATED_SET = []
    for i in CLS_TMP:
        SEPARATED_SET.append(KFOLD_SEPARATION(i))
    FINAL_SET = []
    for i in np.transpose(SEPARATED_SET):
        tmp1 = i[0]
        for j in range(len(i) - 1):
            tmp1 = np.concatenate((tmp1, i[j + 1]))
        FINAL_SET.append(tmp1)

    return FINAL_SET









